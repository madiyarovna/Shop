package com.company;

import com.company.model.Repository.*;
import com.company.model.database.IDB;
import com.company.model.database.PostgresDB;
import com.company.view.Application;

public class Main {

    public static void main(String[] args) {


        IDB db = new PostgresDB();
        IAddRepository addRepository = new AddRepository(db);
        ISearchRepository searchRepository = new SearchRepository(db);

        Application app = new Application(searchRepository, addRepository);



        app.start();

    }
}
