package com.company.controller;

import com.company.model.Repository.IAddRepository;
import com.company.model.entitiies.Product;

public class AddController {
    private final IAddRepository repository;

    public AddController(IAddRepository repository) {
        this.repository = repository;
    }

    public void addNewItem(Product newProduct){
        repository.addNewProduct(newProduct);
    }
}
