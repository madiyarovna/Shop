package com.company.controller;

import com.company.model.Repository.ISearchRepository;
import com.company.model.entitiies.Product;

import java.util.ArrayList;

public class SearchController {
    private final ISearchRepository searchRepository;

    public SearchController(ISearchRepository searchRepository) {
        this.searchRepository = searchRepository;
    }

    public ArrayList < Product > getAllProduct(){
        return searchRepository.getAllProducts();
    }

    public ArrayList < Product > getProductsByType(String type){
        return searchRepository.getProductsType(type);
    }



}
