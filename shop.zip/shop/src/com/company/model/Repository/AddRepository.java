package com.company.model.Repository;

import com.company.model.database.IDB;
import com.company.model.entitiies.Product;

import java.sql.Connection;
import java.sql.PreparedStatement;

public class AddRepository implements IAddRepository{

    private IDB db;

    public AddRepository(IDB db) {
        this.db = db;
    }

    public void addNewProduct(Product newProduct){
        Connection con = null;

        try {
            con = db.getConnection();

            String sql = "insert into products values (default, ?, ?, ?)";
            PreparedStatement st = con.prepareStatement(sql);

            st.setString(1,  newProduct.getName());
            st.setString(2, newProduct.getType());
            st.setInt(3, newProduct.getQuantity());

            st.execute();

        } catch (Exception e){
            System.out.println(e);
        } finally {
            try {
                con.close();
            } catch (Exception e){
                System.out.println(e);
            }
        }
    }
}
