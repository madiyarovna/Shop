package com.company.model.Repository;

import com.company.model.entitiies.Product;

public interface IAddRepository {

    void addNewProduct(Product product);
}
