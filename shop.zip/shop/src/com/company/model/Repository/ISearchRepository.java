package com.company.model.Repository;

import com.company.model.entitiies.Product;

import java.util.ArrayList;

public interface ISearchRepository {
    ArrayList<Product> getAllProducts();
    ArrayList<Product> getProductsType(String type);
}

