package com.company.view;

import com.company.controller.AddController;
import com.company.controller.SearchController;
import com.company.model.Repository.IAddRepository;
import com.company.model.Repository.ISearchRepository;
import com.company.model.entitiies.Product;

import java.util.ArrayList;
import java.util.Scanner;

public class Application {

    private final AddController addController;
    private final SearchController searchController;

    public Application(ISearchRepository searchRepository, IAddRepository addRepository){
        searchController = new SearchController(searchRepository);
        addController = new AddController(addRepository);
    }

    public void start() {

        Scanner in = new Scanner(System.in);

        while(true) {
            System.out.println("Welcome to our shop!");
            System.out.println("1: Show products");
            System.out.println("2: Add new product");
            System.out.println("3: Exit ");

            int choice = in.nextInt();

            if (choice == 1) {
                System.out.println("1: Show all products");
                System.out.println("2: Show products by type");

                choice = in.nextInt();
                if(choice == 1){
                    showAllProducts();
                } else {
                    System.out.println("Input type");
                    String type = in.next();
                    showProductsByType(type);
                }
            } else if (choice == 2) {
                String name, type;
                int quantity;
                System.out.println("Enter name of product:");
                name = in.next();
                System.out.println("Enter type of product");
                type = in.next();
                System.out.println("Enter quantity of product");
                quantity = in.nextInt();

                addNewProduct(new Product(name, type, quantity));

                System.out.println("Success! We added new item \n -----------------------------------------");

            } else {
                System.exit(0);
            }
        }

    }

    void showProductsByType(String type){
        ArrayList <Product> all = searchController.getProductsByType(type);

        if(all == null){
            System.out.println("Empty!");
        } else {
            System.out.println("Total " + all.size() + " products \n -----------------------------------------");

        }

        for(Product p : all){
            System.out.println(p.toString());
        }
        System.out.println("-----------------------------------------");
    }

    void showAllProducts(){
        ArrayList <Product> all = searchController.getAllProduct();

        if(all == null){
            System.out.println("Empty!");
        } else {
            System.out.println("Total " + all.size() + " products \n -----------------------------------------");

        }

        for(Product p : all){
            System.out.println(p.toString());
        }
        System.out.println("-----------------------------------------");
    }

    void addNewProduct(Product newProd){
        addController.addNewItem(newProd);
    }

}

